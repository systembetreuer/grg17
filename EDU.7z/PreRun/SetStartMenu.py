# python3
# -*- coding: utf-8 -*-

import os, glob, socket
import ctypes
import subprocess
import platform
import socket
import sys
import time
import pathlib
import urllib
from pathlib import Path
import shutil, errno
import urllib.request
from datetime import datetime
import random
import winreg

###################################################
# NO MORE - logging the run to a textfile in the setupfolder
###################################################
now = datetime.now()
logdatetime = now.strftime("%H:%M:%S %d.%m.%Y")
print("Starting the python Script at "+logdatetime)

SCVers = 1.1
print("running ScriptVersion: " +str(SCVers))
time.sleep(3)
opsystem = platform.system()
winvers = int(platform.version().split('.')[2])
print(opsystem)
print(winvers)
if opsystem.lower() != "windows":
    print("Sorry - This Program runs only on Windows!")
    msg.showerror(title="Wrong Operating System",message="This Program runs only on Windows!\nNot on " +opsystem+ "")
    sys.exit()
elif winvers < 22000:
    verswin = "10"
    print("detected OS: Windows 10 - "+str(winvers))
elif winvers == 22000:
    verswin = "11H1"
    print("detected OS: Windows 11 21H2 - "+str(winvers))
elif winvers > 22620:
    verswin = "11H2"
    print("detected OS: Windows 11 22H2 - "+str(winvers))
else:
    print("unsupported Windows Version "+str(winvers)+" detected!")
    sys.exit()

with open(r'C:\Windows\EDU\school.txt', 'r') as f:
    school = f.readline().rstrip()
print("School: " +school)

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def countdown(t):
    while t:
        mins, secs = divmod(t, 60)
        timeformat = '{:02d}:{:02d}'.format(mins, secs)
        print(timeformat, end='\r')
        time.sleep(1)
        t -= 1
def lines_that_contain(string, fp):
    return [line for line in fp if string in line]
    
def Customizations():
    print("Prepareing Customizations")
    try:
        if verswin == "10":
            print("exporting Startlayout for Windows " +verswin)
            os.system(r"powershell -command Export-StartLayout -Path $ENV:LOCALAPPDATA\Microsoft\Windows\Shell\LayoutModification.xml ")
            os.system(r"powershell -command Export-StartLayout -Path C:\\Users\\Default\\AppData\\Local\\Microsoft\\Windows\\Shell\\LayoutModification.xml ")
            os.system(r"powershell -command Export-StartLayout -Path C:\Windows\EDU\LayoutModification.xml ")
        if verswin == "11H1":
            print("exporting Startlayout for Windows " +verswin)
            os.system(r"xcopy C:\Users\%username%\AppData\Local\Packages\Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy\LocalState\start.bin C:\Windows\EDU\ /y ")
            print("Start.bin copied")
        if verswin == "11H2":
            print("exporting Startlayout for Windows " +verswin)
            os.system(r"xcopy C:\Users\%username%\AppData\Local\Packages\Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy\LocalState\start2.bin C:\Windows\EDU\ /y ")
            print("Start2.bin copied")
    except:
        pass

if is_admin():
    print("ist bereits Admin!")
    Customizations()
else:
    # Re-run the program with admin rights
    print("ist NOCH NICHT Admin!")
    ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)

print("Ending the python Script")
countdown(5)
quit()
sys.exit()


