$username = $Env:Username
Copy-Item -Path "C:\Windows\EDU\start2.bin" -Destination "C:\Users\$username\Appdata\Local\Packages\Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy\LocalState"
Dism.exe /online /import-defaultappassociations:"C:\Windows\EDU\AppAssoc.xml"
Stop-Process -Name explorer -Force
exit
