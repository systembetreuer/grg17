### Version 20240202 ###
#BG9
Add-PrinterDriver -Name "HP Universal Printing PCL 6" -InfPath "C:\Windows\System32\DriverStore\FileRepository\hpcu270u.inf_amd64_3e20dbae029ad04a\hpcu270u.inf"
Add-PrinterDriver -Name "KONICA MINOLTA Universal PCL" -InfPath "C:\Windows\System32\DriverStore\FileRepository\koax4j__.inf_amd64_ca7131295a6be759\KOAX4J__.inf"
#Add-PrinterPort -Name "EDV1-HP3015" -PrinterHostAddress 10.2.16.1
#Add-PrinterPort -Name "EDV2-HP3005" -PrinterHostAddress 10.2.17.1
#Add-PrinterPort -Name "LAR-Bizhub" -PrinterHostAddress 10.1.18.12

#GRG17
Add-PrinterDriver -Name "KONICA MINOLTA Universal PCL" -InfPath "C:\Windows\System32\DriverStore\FileRepository\koax4j__.inf_amd64_ca7131295a6be759\KOAX4J__.inf"
Add-PrinterDriver -Name "Brother Mono Universal Printer (PCL)" -InfPath "C:\Windows\System32\DriverStore\FileRepository\brupcb0a.inf_amd64_5d1c58716e6374b3\BRUPCB0A.INF"
#Add-PrinterPort -Name "AFRO-Bizhub" -PrinterHostAddress 192.168.100.91
#Add-PrinterPort -Name "EDV1-Brother" -PrinterHostAddress 192.168.100.210
#Add-PrinterPort -Name "EDV2-Brother" -PrinterHostAddress 192.168.100.96
#Add-PrinterPort -Name "LPC-KON" -PrinterHostAddress 192.168.10.243
#Add-PrinterPort -Name "SEK-KON" -PrinterHostAddress 192.168.10.246
#Add-PrinterPort -Name "KOP-KON" -PrinterHostAddress 192.168.10.247

#BRG9
Add-PrinterDriver -Name "Canon Generic Plus UFR II" -InfPath "C:\Windows\System32\DriverStore\FileRepository\cnlb0ma64.inf_amd64_4a4121f38f0e26a0\CNLB0MA64.INF"
#Add-PrinterPort -Name "LuL1Kop" -PrinterHostAddress 192.168.23.14
#Add-PrinterPort -Name "LuL2Kop" -PrinterHostAddress 192.168.23.58
#Add-PrinterPort -Name "BRG9Kop" -PrinterHostAddress 192.168.0.139

#BRG3
Add-PrinterDriver -Name "HP Universal Printing PCL 6" -InfPath "C:\Windows\System32\DriverStore\FileRepository\hpcu270u.inf_amd64_3e20dbae029ad04a\hpcu270u.inf"
Add-PrinterDriver -Name "Lexmark Universal v2" -InfPath "C:\Windows\System32\DriverStore\FileRepository\lmud1o40.inf_amd64_1377b89ec65ef72f\LMUD1o40.inf"
Add-PrinterDriver -Name "Kyocera Classic Universaldriver PCL6 (A4)" -InfPath "C:\Windows\System32\DriverStore\FileRepository\oemsetup.inf_amd64_e0c72d625a275bef\OEMsetup.inf"
Add-PrinterDriver -Name "HP LaserJet Pro M402-M403 n-dne PCL 6" -InfPath "C:\Windows\System32\DriverStore\FileRepository\hpdo602a_x64.inf_amd64_576e5253b855b11a\hpdo602a_x64.inf"
#Add-PrinterPort -Name "EDV1-HP2055dn" -PrinterHostAddress 172.25.1.240
#Add-PrinterPort -Name "EDV2-LexMS510dn" -PrinterHostAddress 172.25.2.240
#Add-PrinterPort -Name "EDV3-KyFS3920dn" -PrinterHostAddress 172.25.3.240
#Add-PrinterPort -Name "EDV4-HPM402n" -PrinterHostAddress 172.26.12.243


