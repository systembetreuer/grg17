<#
NOTES

    Idea based on an original script for Windows 10 app removal / Credit to: Nickolaj Andersen @ MSEndpointMgr
    Modifications to original script to Black list Appx instead of Whitelist

    FileName:    Remove-Appx-AllUsers-CloudSourceList.ps1
    Author:      Ben Whitmore
    Contact:     @byteben
    Date:        27th June 2022

#>

Begin {

    #Log Function
    function Write-LogEntry {
        param (
            [parameter(Mandatory = $true)]
            [ValidateNotNullOrEmpty()]
            [string]$Value,
            [parameter(Mandatory = $false)]
            [ValidateNotNullOrEmpty()]
            [string]$FileName = "AppXRemovalX.log",
            [switch]$Stamp
        )
    
        #Build Log File appending System Date/Time to output
        $LogFile = Join-Path -Path $env:SystemRoot -ChildPath $("EDU\$FileName")
        $Time = -join @((Get-Date -Format "HH:mm:ss.fff"), " ", (Get-WmiObject -Class Win32_TimeZone | Select-Object -ExpandProperty Bias))
        $Date = (Get-Date -Format "MM-dd-yyyy")
    
        If ($Stamp) {
            $LogText = "<$($Value)> <time=""$($Time)"" date=""$($Date)"">"
        }
        else {
            $LogText = "$($Value)"   
        }
        
        Try {
            Out-File -InputObject $LogText -Append -NoClobber -Encoding Default -FilePath $LogFile -ErrorAction Stop
        }
        Catch [System.Exception] {
            Write-Warning -Message "Unable to add log entry to $LogFile.log file. Error message at line $($_.InvocationInfo.ScriptLineNumber): $($_.Exception.Message)"
        }
    }

    #Function to Remove AppxProvisionedPackage
    Function Remove-AppxPackageCustom {

        # Attempt to remove AppxProvisioningPackage
        if (!([string]::IsNullOrEmpty($BlackListedApp))) {
            try {
            
                # Get Package Name
                $AppPackageName = Get-AppxPackage -AllUsers | Select PackageFullName | Where-Object PackageFullName -match $BlackListedApp
                Write-Host "$($BlackListedApp) found. Attempting removal ... " -NoNewline
                Write-LogEntry -Value "$($BlackListedApp) found. Attempting removal ... "

                # Attempt removeal
                $RemoveAppx = Remove-AppxPackage -AllUsers -Package $AppPackageName
                
                #Re-check existence
                $AppPackageNameReCheck = Get-AppxPackage -AllUsers | Select PackageFullName | Where-Object PackageFullName -match $BlackListedApp

                If ([string]::IsNullOrEmpty($AppPackageNameReCheck) -and ($RemoveAppx.Online -eq $true)) {
                    Write-Host @CheckIcon
                    Write-Host " (Removed)"
                    Write-LogEntry -Value "$($BlackListedApp) removed"
                }
            }
            catch [System.Exception] {
                Write-Host " (Failed)"
                Write-LogEntry -Value "Failed to remove $($BlackListedApp)"
            }
        }
    }

    Write-LogEntry -Value "##################################"
    Write-LogEntry -Stamp -Value "Remove-Appx Started"
    Write-LogEntry -Value "##################################"

    #OS Check
    $OS = (Get-CimInstance -ClassName Win32_OperatingSystem).BuildNumber
    Switch -Wildcard ( $OS ) {
        '21*' {
            $OSVer = "Windows 10"
            Write-Warning "This script is intended for use on Windows 11 devices. $($OSVer) was detected..."
            Write-LogEntry -Value "This script is intended for use on Windows 11 devices. $($OSVer) was detected..."
            Exit 1
        }
    }
    # Black List of Appx Provisioned Packages to Remove for All Users
    $BlackListedApps = $null
    $BlackListedApps = New-Object -TypeName System.Collections.ArrayList
    $BlackListedApps.AddRange(@(
    	    "ReaderNotificationClient",
            "MicrosoftWindows.Client.WebExperience",
	    "ReaderNotificationClient",
            "NotepadPlusPlus",
            "Microsoft.Winget.Source",
            "Microsoft.WindowsStore"
        ))
 
    #Define Icons
    $CheckIcon = @{
        Object          = [Char]8730
        ForegroundColor = 'Green'
        NoNewLine       = $true
    }
 
    #Define App Count
    [int]$AppCount = 0

}

Process {

    If ($($BlackListedApps.Count) -ne 0) {

        Write-Output `n"The following $($BlackListedApps.Count) apps were targeted for removal from the device:-"
        Write-LogEntry -Value "The following $($BlackListedApps.Count) apps were targeted for removal from the device:-"
        Write-LogEntry -Value "Apps marked for removal:$($BlackListedApps)"
        Write-Output ""
        $BlackListedApps

        #Initialize list for apps not targeted
        $AppNotTargetedList = New-Object -TypeName System.Collections.ArrayList

        # Get Appx Packages
        Write-Output `n"Gathering installed Appx Packages..."
        Write-LogEntry -Value "Gathering installed Appx Packages..."
        Write-Output ""
        $AppArray = Get-AppxPackage | Select-Object -ExpandProperty DisplayName

        # Loop through each Package
        foreach ($BlackListedApp in $BlackListedApps) {

            # Function call to Remove Appx Packages defined in the Black List
            if (($BlackListedApp -in $AppArray)) {
                $AppCount ++
                Try {
                    Remove-AppxPackageCustom -BlackListedApp $BlackListedApp
                }
                Catch {
                    Write-Warning `n"There was an error while attempting to remove $($BlakListedApp)"
                    Write-LogEntry -Value "There was an error when attempting to remove $($BlakListedApp)"
                }
            }
            else {
                $AppNotTargetedList.AddRange(@($BlackListedApp))
            }
        }

        #Update Output Information
        If (!([string]::IsNullOrEmpty($AppNotTargetedList))) { 
            Write-Output `n"The following apps were not removed. Either they were already removed or the Package Name is invalid:-"
            Write-LogEntry -Value "The following apps were not removed. Either they were already removed or the Package Name is invalid:-"
            Write-LogEntry -Value "$($AppNotTargetedList)"
            Write-Output ""
            $AppNotTargetedList
        }
        If ($AppCount -eq 0) {
            Write-Output `n"No apps were removed. Most likely reason is they had been removed previously."
            Write-LogEntry -Value "No apps were removed. Most likely reason is they had been removed previously."
        }
    }
    else {
        Write-Output "No Black List Apps defined in array"
        Write-LogEntry -Value "No Black List Apps defined in array"
    }
}

