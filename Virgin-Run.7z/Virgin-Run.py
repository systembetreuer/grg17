# python3.13.2
# -*- coding: utf-8 -*-

import os, glob, socket, subprocess, ctypes
import platform, socket, sys, time, urllib, pathlib
import shutil, errno, winreg, random
from pathlib import Path
from datetime import datetime
import winreg, logging, json
subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "pip"])
subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "pypiwin32"])
subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "requests"])
subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "psutil"])
subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "pyunpack"])
subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "multivolumefile"])
subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "patool"])
subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "pycrosskit"])
subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "winwifi"])
subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "certifi"])
subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "pip-system-certs"])
subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "winshell"])
subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "opencv-python"])
try:        
    import requests, psutil, pywintypes
    from pyunpack import Archive
    import urllib.request, multivolumefile, shutil
    import re, importlib, cv2
    #import pythoncom
    from win32com.client import Dispatch 
    import ssl
    ssl._create_default_https_context = ssl._create_stdlib_context
except Exception as e:
    print(f"Error occurred: {e}. Restarting script...")
    # Restart the script
    os.startfile(sys.argv[0])
    sys.exit()

SCVers = 1.1

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

failed_functions = []

def countdown(t):
    while t:
        mins, secs = divmod(t, 60)
        timeformat = '{:02d}:{:02d}'.format(mins, secs)
        print(timeformat, end='\r')
        time.sleep(1)
        t -= 1

def lines_that_contain(string, fp):
    return [line for line in fp if string in line]
 
def reporthook(count, block_size, total_size):
    percent = min(int(count*block_size*100/total_size),100)
    sys.stdout.write("\r...%d%%  " %(percent))
    sys.stdout.flush()
    
def GetPys(url, filename):
    urllib.request.urlretrieve(url, filename, reporthook)
    print(filename+ " " u'\u2705')
    
def CreateFldrs(dldpath):
    if not os.path.exists(dldpath):
        os.makedirs(dldpath)    

def is_package_installed(package_name):
    try:
        importlib.import_module(package_name)
        return True
    except ImportError:
        return False

def KillProcess(process_name):
    for proc in psutil.process_iter(['pid', 'name']):
        if proc.info['name'] == process_name:
            print(f"Found {process_name} running with PID {proc.info['pid']}. Attempting to kill...")
            try:
                proc.kill()
                print(f"Successfully killed {process_name}")
            except psutil.NoSuchProcess:
                print(f"Process already terminated")
            except psutil.AccessDenied:
                print(f"Access denied - need administrator privileges")
            return True
    print(f"{process_name} is not running")
    return False

def minimize_console():
    """Minimize the current console window."""
    ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 6)  # 6 = SW_MINIMIZE

def restore_console():
    """Restore the current console window."""
    ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 9)  # 9 = SW_RESTORE

def RemoveRecoveryPartition():
    try:
        print("\nRemoving Recovery Partition")
        # Get partition list
        diskpart_script = """
        select disk 0
        list partition
        """
        result = subprocess.run(["diskpart"], 
                              input=diskpart_script.encode('utf-8'),
                              capture_output=True, 
                              check=True)
        
        # Decode output
        output = result.stdout.decode('utf-8', errors='ignore')
        
        # Find recovery partition (works for both English/German)
        recovery_part = None
        for line in output.split('\n'):
            if "Recovery" in line or "Wiederherstell" in line:
                match = re.search(r'Partition\s+(\d+)', line)
                if match:
                    recovery_part = match.group(1)
                    break
        
        if not recovery_part:
            print("No recovery partition found")
            return True
        
        recovery_num = int(recovery_part)
        primary_part = recovery_num - 1
        
        print(f"Found recovery partition {recovery_num}, expanding partition {primary_part}")
        
        # Delete recovery and expand primary
        diskpart_script = f"""
        select disk 0
        select partition {recovery_num}
        delete partition override
        select partition {primary_part}
        extend
        exit
        """.encode('utf-8')
        
        subprocess.run(["diskpart"], input=diskpart_script, check=True)
        print("Successfully removed recovery partition and expanded primary partition")
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"Error: {e.stderr.decode('utf-8', errors='ignore')}")
        return False

def Run_BDE(cmd):
    try:
        result = subprocess.run(cmd,
                              stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE,
                              creationflags=subprocess.CREATE_NO_WINDOW)
        return result.stdout.decode('cp850', errors='replace').strip()
    except Exception as e:
        return None

def BDE_Status():
    status = Run_BDE(['manage-bde', '-status', 'C:'])
    if not status:
        return None, None
    
    # Extract just the two key lines we need
    status_lines = status.split('\n')
    conversion = next((line for line in status_lines if "Konvertierungsstatus:" in line), None)
    percent = next((line for line in status_lines if "Verschlüsselt (Prozent):" in line), None)
    
    if conversion and percent:
        return conversion.split(":")[1].strip(), percent.split(":")[1].strip()
        Run_BDE(['manage-bde', '-off', 'C:'])
    return None, None

def Decryptor():
    print("BitLocker-Entschlüsselungsmonitor")
    print("---------------------------------")
#    Run_BDE(['manage-bde', '-resume', 'C:'])
    countdown(5)
    Run_BDE(['manage-bde', '-off', 'C:'])
    
    try:
        while True:
            conversion, percent = BDE_Status()
            if not conversion:
                print("Status konnte nicht gelesen werden")
                break
                
            # Clean up the status text
            clean_status = conversion.replace("Die ", "").replace("wird durchgeführt", "")
            
            # Single line output with updating percentage
            print(f"\r{clean_status} -> {percent}", end='', flush=True)
            
            # Check if decryption is complete
            if "vollständig entschlüsselt" in conversion.lower():
                print("\nEntschlüsselung abgeschlossen!")
                break
                
            time.sleep(5)
            
    except KeyboardInterrupt:
        print("\nMonitoring beendet. Entschlüsselung läuft weiter im Hintergrund.")

def Build7Zip():
    try:
        if is_package_installed('py7zr'):
            print("Py7zr is installed")
        else:
            print("\nstarting Visual Studio Update")
            GetPys("https://aka.ms/vs/17/release/vs_BuildTools.exe", "C:\\Windows\\EDU\\vbt.exe")    
            os.system("C:\\Windows\\EDU\\vbt.exe --norestart --passive --downloadThenInstall --includeRecommended --add Microsoft.VisualStudio.Workload.NativeDesktop --add Microsoft.VisualStudio.Workload.VCTools --add Microsoft.VisualStudio.Workload.MSBuildTools")
            print("trying setup.exe for VisualStudio Installer after 30 seconds of waittime .....")
            time.sleep(30) ### sleepwalking into second Route
            vTr = "setup.exe" in (p.name() for p in psutil.process_iter())
            counter_vtr = 0
            while (vTr == True):
                process_vtr = 0
                counter_vtr += 1
                for p in psutil.process_iter(attrs=['name']):
                    name = ((p.info['name']).split('\\')[0]) 
                    if p.info['name'] == 'setup.exe':
                        process_vtr += 1
                        show_sec = (counter_vtr*10)
                print("Process Counter: "+str(show_sec)+" seconds | "+str(process_vtr), end='\r')
                time.sleep(10)
                vTr = "setup.exe" in (p.name() for p in psutil.process_iter())
                if process_vtr < 2: 
                    vTr = False
            subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "py7zr"]) 
        import py7zr                    
        print("Done with Visual Studio Update")
    except Exception as e:
        current_func = sys._getframe().f_code.co_name
        print(f"Error in {current_func}: {e}")
        # Get the actual function object from the current module
        func_obj = globals()[current_func]
        failed_functions.append(func_obj)
        return False
    return True 

def FirstRun():
    destination = "C:\\Windows\\EDU\\"
    CreateFldrs(destination)
    if not os.path.isfile(destination+'/'+'school.txt'):
        while True:
            nschool = input("Enter School [BRG3 | BG9 | BRG9 | GRg17]: \n")
            if nschool == "BRG3" or nschool == "BRG9" or nschool == "BG9" or nschool == "GRg17" or nschool == "UNI":
                with open(destination+'/'+'school.txt', 'x') as the_file:
                    the_file.write(nschool+'\n')
                break
            else:
                print("Hey Stupid, choose the right school!!!")
    with open(r'C:\\Windows\\EDU\\school.txt', 'r') as f:
        school = f.readline().rstrip()
    print("School: " +school)          
        
def Download_PYs():
    try:
        print("\nDownloading all necassary files")
        GetPys("https://gist.githubusercontent.com/systembetreuer/a0b59cab527f6fd0e4575a201c8a774a/raw/PreRunGist.py", "C:\\Windows\\EDU\\PreRun\\PreRunGist.py")
        GetPys("https://gist.githubusercontent.com/systembetreuer/3f95f75eda0f029a66a1a2cfa50e463b/raw/AIO-REG.reg", "C:\\Windows\\EDU\\AIO-REG.reg")
        GetPys("https://raw.githubusercontent.com/systembetreuer/grg17/main/Firefoxes.7z", "C:\\Windows\\Setup\\Firefoxes.7z")
        GetPys("https://raw.githubusercontent.com/systembetreuer/grg17/main/EDU.7z", "C:\\Windows\\Setup\\EDU.7z")
        GetPys("https://gist.githubusercontent.com/systembetreuer/2eb3ea92d9e80db5ff826a8f0e90a8d5/raw/PreRunExec.py", "C:\\Windows\\EDU\\PreRun\\PreRunExec.py")
        GetPys("https://github.com/microsoft/winget-cli/releases/download/v1.10.390/Microsoft.DesktopAppInstaller_8wekyb3d8bbwe.msixbundle", "C:\\Windows\\EDU\\Software\\Microsoft.DesktopAppInstaller_8wekyb3d8bbwe.msixbundle")
        GetPys("https://raw.githubusercontent.com/systembetreuer/grg17/main/Dependencies.7z", "C:\\Windows\\Setup\\Dependencies.7z")
        GetPys("https://raw.githubusercontent.com/systembetreuer/grg17/main/NSudo.7z", "C:\\Windows\\Setup\\NSudo.7z")
        GetPys("https://github.com/marticliment/UniGetUI/releases/download/3.1.8/UniGetUI.Installer.exe", "C:\\Windows\\EDU\\Software\\UniGetUI.Installer.exe")
        GetPys("https://raw.githubusercontent.com/systembetreuer/grg17/main/BaseInstall.ubundle", "C:\\Windows\\EDU\\Software\\BaseInstall.ubundle")
        GetPys("https://raw.githubusercontent.com/systembetreuer/grg17/main/Victory.mp4.7z.001", "C:\\Windows\\EDU\\NewPrntDrvs\\Victory.mp4.7z.001")
        GetPys("https://raw.githubusercontent.com/systembetreuer/grg17/main/Victory.mp4.7z.002", "C:\\Windows\\EDU\\NewPrntDrvs\\Victory.mp4.7z.002")
        GetPys("https://raw.githubusercontent.com/systembetreuer/grg17/main/Office2024-x64.7z", "C:\\Windows\\Setup\\Office2024-x64.7z")
    except Exception as e:
        current_func = sys._getframe().f_code.co_name
        print(f"Error in {current_func}: {e}")
        # Get the actual function object from the current module
        func_obj = globals()[current_func]
        failed_functions.append(func_obj)
        return False
    return True 

     
def AddRegFile():
    try:
        print("\nInstalling Registry Entries")
        subprocess.call(['reg', 'import', "C:\\Windows\\EDU\\AIO-REG.reg"])
    except:
        pass
 
def Unpack7Zip(z7file, z7path):
    import py7zr
    try:
        if os.path.exists(z7file):
            with py7zr.SevenZipFile(z7file, 'r') as z:
                z.extractall(path=z7path)
                print("Zipfile was extracted")
        else:
            print("7Zip File: "+z7file+" not found!")
    except Exception as e:
        current_func = sys._getframe().f_code.co_name
        print(f"Error in {current_func}: {e}")
        # Get the actual function object from the current module
        func_obj = globals()[current_func]
        failed_functions.append(func_obj)
        return False
    return True 

def UnPackDrvs_PYTO(destination):
    import py7zr
    try:
        source = "C:\\Windows\\EDU\\NewPrntDrvs\\"
        if not os.path.exists(destination):
            os.makedirs(destination)
        allfiles = os.listdir(source)
        for f in allfiles:
            src_path = os.path.join(source, f)
            dst_path = os.path.join(destination, f)
            os.rename(src_path, dst_path)        
        print("extracting Files")    
        with multivolumefile.open('C:\\Windows\\EDU\\Software\\Victory.mp4.7z', mode='rb') as target_archive:
            print(target_archive)
            with py7zr.SevenZipFile(target_archive, 'r', header_encryption=False) as archive:
                archive.extractall(destination)
        files = os.listdir(destination)
        os.remove('C:\\Windows\\EDU\\Software\\Victory.mp4.7z.001')
        os.remove('C:\\Windows\\EDU\\Software\\Victory.mp4.7z.002')
        shutil.move("C:\\Windows\\EDU\\Software\\Vicki\\Victory.mp4", "C:\\Windows\\EDU\\Software\\Victory.mp4")
        shutil.rmtree("C:\\Windows\\EDU\\Software\\Vicki")
        print("extracting DONE")
    except Exception as e:
        current_func = sys._getframe().f_code.co_name
        print(f"Error in {current_func}: {e}")
        # Get the actual function object from the current module
        func_obj = globals()[current_func]
        failed_functions.append(func_obj)
        return False
    return True 

def InstallPSWindowsUpdate():
    try:
        print("\nInstalling PS Windows Update")
        os.system('powershell -command "Import-Module Microsoft.PowerShell.Security -force"')
        os.system('powershell -command "Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -force"')
        os.system('powershell -command "Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force"')
        os.system('powershell -command "Install-Module -Name PSWindowsUpdate -Force"')
        print("PSWindowsUpdate was installed")
    except Exception as e:
        current_func = sys._getframe().f_code.co_name
        print(f"Error in {current_func}: {e}")
        # Get the actual function object from the current module
        func_obj = globals()[current_func]
        failed_functions.append(func_obj)
        return False
    return True 
        
def ProvPackages():
    try:
        print("\nInstalling Provisioned Packages")
        subprocess.Popen(r'dism /Online /Add-ProvisionedAppxPackage /PackagePath:"C:\Windows\EDU\Software\Microsoft.WebpImageExtension.AppxBundle" /SkipLicense ').wait()
        subprocess.Popen(r'dism /Online /Add-ProvisionedAppxPackage /PackagePath:"C:\Windows\EDU\Software\Microsoft.UI.Xaml.appx" /SkipLicense ').wait()
        subprocess.Popen(r'dism /Online /Add-ProvisionedAppxPackage /PackagePath:"C:\Windows\EDU\Software\Microsoft.VCLibs.appx" /SkipLicense ').wait()
        subprocess.Popen(r'dism /Online /Add-ProvisionedAppxPackage /PackagePath:"C:\Windows\EDU\Software\Microsoft.DesktopAppInstaller_8wekyb3d8bbwe.msixbundle" /SkipLicense').wait()
    except Exception as e:
        current_func = sys._getframe().f_code.co_name
        print(f"Error in {current_func}: {e}")
        # Get the actual function object from the current module
        func_obj = globals()[current_func]
        failed_functions.append(func_obj)
        return False
    return True        

def RestoreMenu():
    try:
        print("\nRestoring Old Menu")
        os.system('C:\\Windows\\EDU\\Software\\NSudo\\NSudoLC.exe /U:T regedit /s "C:\\Windows\\EDU\\Software\\NSudo\\RegOldMenu.reg"')
    except Exception as e:
        current_func = sys._getframe().f_code.co_name
        print(f"Error in {current_func}: {e}")
        # Get the actual function object from the current module
        func_obj = globals()[current_func]
        failed_functions.append(func_obj)
        return False
    return True 
        
def Remove(filepath):
    try:
        if os.path.exists(filepath):
            if os.path.isfile(filepath):
                os.remove(filepath)
            elif os.path.isdir(filepath):
                shutil.rmtree(filepath)
    except:
        print("EXCEPTION: Remove FAILED")
        pass
        
def InstallOffice(config):
    try:
        print("\nstarting Installation of Office: " +config)
        subprocess.Popen('C:\\Windows\\EDU\\Software\\Office\\setup.exe /configure "C:\\Windows\\EDU\\Software\\Office\\OfficeVL'+config+'.xml')
        print("trying OfficeClickToRun.exe for Office Installation after 30 seconds .....")
        time.sleep(30) ### sleepwalking into second Route
        cTr = "OfficeClickToRun.exe" in (p.name() for p in psutil.process_iter())
        while (cTr == True):
            process_ctr = 0
            for p in psutil.process_iter(attrs=['name']):
                name = ((p.info['name']).split('\\')[0]) 
                if p.info['name'] == 'OfficeClickToRun.exe':
                    process_ctr += 1
            print("Process Counter: "+str(process_ctr), end='\r')
            time.sleep(5)
            cTr = "OfficeClickToRun.exe" in (p.name() for p in psutil.process_iter())
            if process_ctr < 2: 
                cTr = False
        time.sleep(10)
        C2R = "OfficeC2RClient.exe" in (p.name() for p in psutil.process_iter())
        if C2R:
            KillProcess("OfficeC2RClient.exe")
        print("Done with installing Office")
    except Exception as e:
        current_func = sys._getframe().f_code.co_name
        print(f"Error in {current_func}: {e}")
        # Get the actual function object from the current module
        func_obj = globals()[current_func]
        failed_functions.append(func_obj)
        return False
    return True                        

def GeoGeb():
    try:
        print("\nInstalling Geogebra 5 & 6")
        GetPys("https://download.geogebra.org/installers/5.2/version.txt", "C:\\Windows\\EDU\\Software\\GeoGebra5.txt")
        GetPys("https://download.geogebra.org/installers/6.0/version.txt", "C:\\Windows\\EDU\\Software\\GeoGebra6.txt")    
        with open('C:\\Windows\\EDU\\Software\\GeoGebra5.txt', 'r') as file:
            ver_geogebra5 = file.read().rstrip()
        print("Version of GeoGebra5 is: " +ver_geogebra5)
        with open('C:\\Windows\\EDU\\Software\\GeoGebra6.txt', 'r') as file:
            ver_geogebra6 = file.read().rstrip()
        print("Version of GeoGebra6 is: " +ver_geogebra6)
        GetPys("https://download.geogebra.org/installers/5.2/GeoGebra-Windows-Installer-"+ver_geogebra5+".msi", "C:\\Windows\\EDU\\Software\\GeoGebra5.msi")
        GetPys("https://download.geogebra.org/installers/6.0/GeoGebra-Windows-Installer-"+ver_geogebra6+".msi", "C:\\Windows\\EDU\\Software\\GeoGebra6.msi")
        print("installing GeoGebra 5")
        subprocess.call('msiexec /i C:\\Windows\\EDU\\Software\\GeoGebra5.msi ALLUSERS=2 /qr', shell=True)
        print("installing GeoGebra 6")
        CreateShortcuts(r"C:\Program Files (x86)\GeoGebra 5.2\GeoGebra.exe", "GeoGebra 5.lnk")
        subprocess.call('msiexec /i C:\\Windows\\EDU\\Software\\GeoGebra6.msi ALLUSERS=2 /qr', shell=True)
        print("Cleaning up")
        os.rename('C:\\Users\\Public\\Desktop\\GeoGebra.lnk','C:\\Users\\Public\\Desktop\\GeoGebra 6.lnk')
        Remove("C:\\Windows\\EDU\\Software\\GeoGebra5.msi")
        Remove("C:\\Windows\\EDU\\Software\\GeoGebra6.msi")
        Remove("C:\\Windows\\EDU\\Software\\GeoGebra5.txt")
        Remove("C:\\Windows\\EDU\\Software\\GeoGebra6.txt")
        print("installing done")        
    except Exception as e:
        current_func = sys._getframe().f_code.co_name
        print(f"Error in {current_func}: {e}")
        # Get the actual function object from the current module
        func_obj = globals()[current_func]
        failed_functions.append(func_obj)
        return False
    return True
        
def UniGet():
    try:
        restore_console()
        print("*******************************************************************\n\nDONT FORGET TO CLOSE UNIGETUI IN TASKBAR AFTER INSTALLING EVERTHING\n\n*******************************************************************")
        time.sleep(5)    
        subprocess.Popen(r'C:\Windows\EDU\Software\UniGetUI.Installer.exe /ALLUSERS /NoChocolatey /SILENT').wait()
        input("done installing UniGetUI\nPress any Key")
        Remove("C:\\Windows\\EDU\\Software\\UniGetUI.Installer.exe")
        KillProcess("UniGetUI.exe")
    except Exception as e:
        current_func = sys._getframe().f_code.co_name
        print(f"Error in {current_func}: {e}")
        # Get the actual function object from the current module
        func_obj = globals()[current_func]
        failed_functions.append(func_obj)
        return False
    return True

def CreateShortcuts(ziel_pfad, verknuepfung_name):
    try:
        public_desktop = os.path.join(os.environ["PUBLIC"], "Desktop")
        shotcut_path = os.path.join(public_desktop, verknuepfung_name)
        shell = Dispatch('WScript.Shell')
        shortcut = shell.CreateShortCut(shotcut_path)
        shortcut.Targetpath = ziel_pfad
        shortcut.WorkingDirectory = os.path.dirname(ziel_pfad)
        shortcut.Description = f"Verknüpfung zu {os.path.basename(ziel_pfad)}"
        shortcut.Save()
        print(f"Shortcut was created: {shotcut_path}")
    except Exception as e:
        print(f"Error creating Shortcut: {e}")
        pass

def AfterMath():
    try:
        print("\nDoing the Aftermath")
        os.system(r'xcopy C:\Windows\EDU\Autostart\AIO.lnk "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup\" /y ')
        os.system('powershell -command "Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -force"')
        subprocess.Popen("python C:\\Windows\\EDU\\PreRun\\PreRunExec.py").wait()
        subprocess.Popen("python C:\\Windows\\EDU\\AIO.pyw").wait()
    except:
        print("EXCEPTION: AfterMath FAILED")
        pass
        
def InstallApps():
    try:
        print("*******************************************************************\n\nDONT FORGET TO CLOSE UNIGETUI IN TASKBAR AFTER INSTALLING EVERTHING\n\n*******************************************************************")
        time.sleep(5)
        subprocess.Popen(r'C:\Program Files\UniGetUI\UniGetUI.exe C:\Windows\EDU\Software\BaseInstall.ubundle').wait()
        print("done with UniGetUI")
    except Exception as e:
        current_func = sys._getframe().f_code.co_name
        print(f"Error in {current_func}: {e}")
        # Get the actual function object from the current module
        func_obj = globals()[current_func]
        failed_functions.append(func_obj)
        return False
    return True 
        
def VictoryVideo(video_path):
    print("\nWell Baby, here we are")
    try:
        import vlc
        instance = vlc.Instance()
        player = instance.media_player_new()
        media = instance.media_new(video_path)
        player.set_media(media)
        player.set_fullscreen(True)
        player.play()
        time.sleep(0.5)
        
        while player.is_playing():
            time.sleep(1)
        player.stop()
    except Exception as e:
        current_func = sys._getframe().f_code.co_name
        print(f"Error in {current_func}: {e}")
        # Get the actual function object from the current module
        func_obj = globals()[current_func]
        failed_functions.append(func_obj)
        return False
    return True 
        
def Reboot():
    os.system("shutdown /a")
    print("rebooting System in 30 Seconds")
    os.system("shutdown /r /t 30")        

def main():
    FirstRun()
    Decryptor()
    RemoveRecoveryPartition()
    Remove("C:\\Windows.old")
    CreateFldrs("C:\\Windows\\EDU\\Wallpaper")
    CreateFldrs("C:\\Windows\\EDU\\NewPrntDrvs")
    CreateFldrs("C:\\Windows\\EDU\\PreRun")
    CreateFldrs("C:\\Windows\\EDU\\Autostart")
    CreateFldrs("C:\\Windows\\EDU\\AIO-Drivers")
    CreateFldrs("C:\\Windows\\EDU\\PrntDrvs")
    CreateFldrs("C:\\Windows\\EDU\\Software")
    CreateFldrs("C:\\Windows\\EDU\\Software\\Office")
    CreateFldrs("C:\\Windows\\Setup\\Scripts")
    Download_PYs()
    UniGet()
    time.sleep(15)
    InstallApps()
    Build7Zip()
    InstallPSWindowsUpdate()
    Unpack7Zip("C:\\Windows\\Setup\\Firefoxes.7z", "C:\\Windows\\Setup")
    Unpack7Zip("C:\\Windows\\Setup\\EDU.7z", "C:\\Windows\\EDU")
    Unpack7Zip("C:\\Windows\\Setup\\Dependencies.7z", "C:\\Windows\\EDU\\Software")
    Unpack7Zip("C:\\Windows\\Setup\\NSudo.7z", "C:\\Windows\\EDU\\Software")
    Unpack7Zip("C:\\Windows\\Setup\\Office2024-x64.7z", "C:\\Windows\\EDU\\Software\\Office")
    UnPackDrvs_PYTO("C:\\Windows\\EDU\\Software")
    CreateShortcuts("C:\\Windows\\EDU\\PreRun\\PreRunExec.py", "PreRunExec.py.lnk")
    CreateShortcuts("C:\\Windows\\EDU\\PreRun\\SetStartMenu.py", "SetStartMenu.py.lnk")    
    AddRegFile()
    ProvPackages()
    RestoreMenu()
    minimize_console()
    InstallOffice("2025Dual")  
    GeoGeb()
    subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "python-vlc"])
    import vlc    
    AfterMath()
    Remove("C:\\Windows\\EDU\\Software\\GeoGebra5.msi")
    Remove("C:\\Windows\\EDU\\Software\\GeoGebra6.msi")
    Remove("C:\\Windows\\EDU\\Software\\GeoGebra5.txt")
    Remove("C:\\Windows\\EDU\\Software\\GeoGebra6.txt")
    Remove("C:\\Windows\\EDU\\Software\\NSudo")
    minimize_console()
    VictoryVideo("C:\\Windows\\EDU\\Software\\Victory.mp4")
    # Retry failed functions once
    if failed_functions:
        print("\nRetrying failed functions...")
        time.sleep(3)
        retry_functions = failed_functions.copy()
        failed_functions.clear()  # Clear for the retry
        
        for func in retry_functions:
            print(f"Retrying {func.__name__}...")
            func()
    
    # Final report
    if failed_functions:
        print("\nThe following functions failed after retry:")
        for func in failed_functions:
            print(f"- {func.__name__}")
    else:
        print("\nAll functions completed successfully (some after retry)")    
    Reboot()

if is_admin():
    print("ist bereits Admin!")
else:
    # Re-run the program with admin rights
    print("ist NOCH NICHT Admin!")
    ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
    
if __name__ == "__main__":
    main()     

time.sleep(20)
quit()
sys.exit()

